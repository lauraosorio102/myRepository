
import java.util.Date;

public class Prestamo {

    String codigo;
    Estudiante estudiante;
    Libro libro;
    Date fechaPrestamo;
    Date fechaEntrega;
    double costo;

    public Prestamo(String codigo, Estudiante estudiante, Libro libro, Date fechaPrestamo) {
        this.codigo = codigo;
        this.estudiante = estudiante;
        this.libro = libro;
        this.fechaPrestamo = fechaPrestamo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public Date getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(Date fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    @Override
    public String toString() {
        return "Prestamo{" +
                "codigo='" + codigo + '\'' +
                ", estudiante=" + estudiante +
                ", libro=" + libro +
                ", fechaPrestamo=" + fechaPrestamo +
                ", fechaEntrega=" + fechaEntrega +
                ", costo=" + costo +
                '}';
    }

    public void entregar(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
        long dias = (fechaEntrega.getTime() - fechaPrestamo.getTime()) / (1000 * 60 * 60 * 24);
        costo = dias * 1.0; // Asumiendo un costo de 1.0 por día
        libro.unidadesDisponibles++;
    }
}

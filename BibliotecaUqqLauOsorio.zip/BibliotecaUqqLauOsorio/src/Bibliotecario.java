public class Bibliotecario extends Persona {
    double salario;
    int aniosAntiguedad;

    public Bibliotecario(String nombre, String cedula, String telefono, String correo, double salario, int aniosAntiguedad) {
        super(nombre, cedula, telefono, correo);
        this.salario = salario;
        this.aniosAntiguedad = aniosAntiguedad;
    }

    public double calcularSalario() {
        double comision = 0.2 * BibliotecaUq.totalDineroRecaudado; // Por cada préstamo
        double bonificacion = 0.02 * comision * aniosAntiguedad;
        return salario + comision + bonificacion;
    }
}

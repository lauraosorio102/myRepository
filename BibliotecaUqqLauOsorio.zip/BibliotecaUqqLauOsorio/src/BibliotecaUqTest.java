
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class BibliotecaUqTest {

    private BibliotecaUq biblioteca;
    private Estudiante estudiante;
    private Bibliotecario bibliotecario;
    private Libro libro;

    @BeforeEach
    void setUp() {
        biblioteca = new BibliotecaUq();
        estudiante = new Estudiante("Juan Pérez", "123456789", "555-1234", "juan@ejemplo.com");
        bibliotecario = new Bibliotecario("Ana Gómez", "987654321", "555-5678", "ana@ejemplo.com", 1000, 5);
        libro = new Libro("lib001", "978-3-16-148410-0", "Autor Ejemplo", "Título Ejemplo", "Editorial Ejemplo", new Date(), 10);

        biblioteca.agregarEstudiante(estudiante);
        biblioteca.agregarBibliotecario(bibliotecario);
        biblioteca.agregarLibro(libro);
    }

    @Test
    void testCrearEstudiante() {
        assertEquals("Juan Pérez", estudiante.nombre);
        assertEquals("123456789", estudiante.cedula);
    }

    @Test
    void testCrearBibliotecario() {
        assertEquals("Ana Gómez", bibliotecario.nombre);
        assertEquals(1000, bibliotecario.salario);
    }

    @Test
    void testCalcularSalarioBibliotecario() {
        BibliotecaUq.totalDineroRecaudado = 10000; // Simular recaudación
        assertEquals(2000, bibliotecario.calcularSalario(), 0.01); // 20% de comisión + bonificación
    }

    @Test
    void testAgregarLibro() {
        assertNotNull(biblioteca.libros.get("lib001"));
    }

    @Test
    void testCrearPrestamo() {
        assertEquals(10, libro.unidadesDisponibles); // Antes del préstamo
        String codigoPrestamo = "prestamo001";
        Prestamo prestamo = new Prestamo(codigoPrestamo, estudiante, libro, new Date());
        biblioteca.crearPrestamo(prestamo);

        // Simular que se realiza el préstamo
        libro.unidadesDisponibles--;

        assertEquals(9, libro.unidadesDisponibles); // Después del préstamo
    }
}

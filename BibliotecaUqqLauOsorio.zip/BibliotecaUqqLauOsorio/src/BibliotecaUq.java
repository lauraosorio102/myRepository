import java.util.*;

public class BibliotecaUq {

    static double totalDineroRecaudado = 0;
    static Map<String, Libro> libros = new HashMap<>();
    static Map<String, Estudiante> estudiantes = new HashMap<>();
    static Map<String, Bibliotecario> bibliotecarios = new HashMap<>();
    static List<Prestamo> prestamos = new ArrayList<>();

    public static void agregarLibro(Libro libro) {
        libros.put(libro.codigo, libro);
    }

    public static void agregarEstudiante(Estudiante estudiante) {
        estudiantes.put(estudiante.cedula, estudiante);
    }

    public static void agregarBibliotecario(Bibliotecario bibliotecario) {
        bibliotecarios.put(bibliotecario.cedula, bibliotecario);
    }

    public static void crearPrestamo(Prestamo prestamo) {
        prestamos.add(prestamo);
    }

    public static int consultarCantidadPrestamosPorLibro(String codigoLibro) {
        return (int) prestamos.stream().filter(p -> p.libro.getCodigo().equals(codigoLibro)).count();
    }

    public static void reemplazarLibro(String codigoViejo, Libro libroNuevo) {
        libros.put(codigoViejo, libroNuevo);
    }

    public static void mostrarPrestamosPorBibliotecario(String cedulaBibliotecario) {
        long cantidad = prestamos.stream().filter(p -> p.estudiante.cedula.equals(cedulaBibliotecario)).count();
        System.out.println("Cantidad de préstamos realizados por el bibliotecario: " + cantidad);
    }
}

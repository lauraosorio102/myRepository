import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final SimpleDateFormat fechaFormato = new SimpleDateFormat("yyyy-MM-dd");

    public static void main(String[] args) {
        BibliotecaUq bibliotecaUq = new BibliotecaUq();

        while (true) {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Agregar Libro");
            System.out.println("2. Agregar Estudiante");
            System.out.println("3. Agregar Bibliotecario");
            System.out.println("4. Crear Préstamo");
            System.out.println("5. Entregar Préstamo");
            System.out.println("6. Consultar Cantidad de Préstamos por Libro");
            System.out.println("7. Reemplazar Libro");
            System.out.println("8. Mostrar Préstamos por Bibliotecario");
            System.out.println("9. Salir");
            System.out.print("Opción: ");
            int opcion = Integer.parseInt(scanner.nextLine());

            if (opcion == 9) {
                break;
            }

            switch (opcion) {
                case 1:
                    agregarLibro(bibliotecaUq);
                    break;
                case 2:
                    agregarEstudiante(bibliotecaUq);
                    break;
                case 3:
                    agregarBibliotecario(bibliotecaUq);
                    break;
                case 4:
                    crearPrestamo(bibliotecaUq);
                    break;
                case 5:
                    entregarPrestamo(bibliotecaUq);
                    break;
                case 6:
                    consultarPrestamosPorLibro(bibliotecaUq);
                    break;
                case 7:
                    reemplazarLibro(bibliotecaUq);
                    break;
                case 8:
                    mostrarPrestamosPorBibliotecario(bibliotecaUq);
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
        scanner.close();
    }

    private static void agregarLibro(BibliotecaUq biblioteca) {
        System.out.print("Ingrese el código del libro: ");
        String codigo = scanner.nextLine();
        System.out.print("Ingrese el ISBN: ");
        String isbn = scanner.nextLine();
        System.out.print("Ingrese el autor: ");
        String autor = scanner.nextLine();
        System.out.print("Ingrese el título: ");
        String titulo = scanner.nextLine();
        System.out.print("Ingrese la editorial: ");
        String editorial = scanner.nextLine();
        System.out.print("Ingrese la fecha (formato: año-mes-día): ");
        Date fecha = leerFecha();
        System.out.print("Ingrese el número de unidades disponibles: ");
        int unidadesDisponibles = Integer.parseInt(scanner.nextLine());

        Libro libro = new Libro(codigo, isbn, autor, titulo, editorial, fecha, unidadesDisponibles);
        biblioteca.agregarLibro(libro);
        System.out.println("Libro agregado con éxito.");
    }

    private static void agregarEstudiante(BibliotecaUq biblioteca) {
        System.out.print("Ingrese el nombre del estudiante: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese la cédula: ");
        String cedula = scanner.nextLine();
        System.out.print("Ingrese el teléfono: ");
        String telefono = scanner.nextLine();
        System.out.print("Ingrese el correo: ");
        String correo = scanner.nextLine();

        Estudiante estudiante = new Estudiante(nombre, cedula, telefono, correo);
        biblioteca.agregarEstudiante(estudiante);
        System.out.println("Estudiante agregado con éxito.");
    }

    private static void agregarBibliotecario(BibliotecaUq biblioteca) {
        System.out.print("Ingrese el nombre del bibliotecario: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese la cédula: ");
        String cedula = scanner.nextLine();
        System.out.print("Ingrese el teléfono: ");
        String telefono = scanner.nextLine();
        System.out.print("Ingrese el correo: ");
        String correo = scanner.nextLine();
        System.out.print("Ingrese el salario: ");
        double salario = Double.parseDouble(scanner.nextLine());
        System.out.print("Ingrese los años de antigüedad: ");
        int aniosAntiguedad = Integer.parseInt(scanner.nextLine());

        Bibliotecario bibliotecario = new Bibliotecario(nombre, cedula, telefono, correo, salario, aniosAntiguedad);
        biblioteca.agregarBibliotecario(bibliotecario);
        System.out.println("Bibliotecario agregado con éxito.");
    }

    private static void crearPrestamo(BibliotecaUq biblioteca) {
        System.out.print("Ingrese el código del préstamo: ");
        String codigo = scanner.nextLine();
        System.out.print("Ingrese la cédula del estudiante: ");
        String cedulaEstudiante = scanner.nextLine();
        Estudiante estudiante = biblioteca.estudiantes.get(cedulaEstudiante);
        if (estudiante == null) {
            System.out.println("Estudiante no encontrado.");
            return;
        }
        System.out.print("Ingrese el código del libro: ");
        String codigoLibro = scanner.nextLine();
        Libro libro = biblioteca.libros.get(codigoLibro);
        if (libro == null || libro.unidadesDisponibles <= 0) {
            System.out.println("Libro no disponible.");
            return;
        }
        libro.unidadesDisponibles--;
        Prestamo prestamo = new Prestamo(codigo, estudiante, libro, new Date());
        biblioteca.crearPrestamo(prestamo);
        System.out.println("Préstamo creado con éxito.");
    }

    private static void entregarPrestamo(BibliotecaUq biblioteca) {
        System.out.print("Ingrese el código del préstamo: ");
        String codigoPrestamo = scanner.nextLine();
        Prestamo prestamo = biblioteca.prestamos.stream()
                .filter(p -> p.getCodigo().equals(codigoPrestamo))
                .findFirst()
                .orElse(null);
        if (prestamo == null) {
            System.out.println("Préstamo no encontrado.");
            return;
        }
        System.out.print("Ingrese la fecha de entrega (formato: año-mes-día): ");
        Date fechaEntrega = leerFecha();
        prestamo.entregar(fechaEntrega);
        BibliotecaUq.totalDineroRecaudado += prestamo.getCosto();
        System.out.println("Préstamo entregado. Costo: " + prestamo.getCosto());
    }

    private static void consultarPrestamosPorLibro(BibliotecaUq biblioteca) {
        System.out.print("Ingrese el código del libro: ");
        String codigoLibro = scanner.nextLine();
        int cantidad = biblioteca.consultarCantidadPrestamosPorLibro(codigoLibro);
        System.out.println("Cantidad de préstamos para el libro: " + cantidad);
    }

    private static void reemplazarLibro(BibliotecaUq biblioteca) {
        System.out.print("Ingrese el código del libro a reemplazar: ");
        String codigoViejo = scanner.nextLine();
        System.out.print("Ingrese el nuevo código del libro: ");
        String codigoNuevo = scanner.nextLine();
        System.out.print("Ingrese el ISBN: ");
        String isbn = scanner.nextLine();
        System.out.print("Ingrese el autor: ");
        String autor = scanner.nextLine();
        System.out.print("Ingrese el título: ");
        String titulo = scanner.nextLine();
        System.out.print("Ingrese la editorial: ");
        String editorial = scanner.nextLine();
        System.out.print("Ingrese la fecha (formato: año-mes-día): ");
        Date fecha = leerFecha();
        System.out.print("Ingrese el número de unidades disponibles: ");
        int unidadesDisponibles = Integer.parseInt(scanner.nextLine());

        Libro libroNuevo = new Libro(codigoNuevo, isbn, autor, titulo, editorial, fecha, unidadesDisponibles);
        biblioteca.reemplazarLibro(codigoViejo, libroNuevo);
        System.out.println("Libro reemplazado con éxito.");
    }

    private static void mostrarPrestamosPorBibliotecario(BibliotecaUq biblioteca) {
        System.out.print("Ingrese la cédula del bibliotecario: ");
        String cedula = scanner.nextLine();
        biblioteca.mostrarPrestamosPorBibliotecario(cedula);
    }

    private static Date leerFecha() {
        while (true) {
            try {
                String fechaStr = scanner.nextLine();
                return fechaFormato.parse(fechaStr);
            } catch (ParseException e) {
                System.out.println("Fecha incorrecta. Por favor, ingrese la fecha en el formato correcto (año-mes-día):");
            }
        }
    }
}